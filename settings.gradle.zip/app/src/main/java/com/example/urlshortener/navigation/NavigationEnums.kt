package com.example.urlshortener.navigation

enum class NavigationEnums {
    
    HOME,
    RESULTS,
    LOADING,
    HISTORY

}